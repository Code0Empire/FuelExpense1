public class Fuel {

    private String carType;
    private int startKms;
    private int endKms;
    private double litersUsed;
    private double pricePerLiter;

    public Fuel(String carType, int endKms, int startKms,
                double litersUsed, double pricePerLiter) {

        this.carType = carType;
        this.endKms = endKms;
        this.startKms = startKms;
        this.litersUsed = litersUsed;
        this.pricePerLiter = pricePerLiter;
    }

    public int calcDistance(int startKms, int endKms) {
        return endKms - startKms;
    }

    public double calcKmPL(int dist, double liters) {
        return dist / liters;
    }

    public double calcLiterP100Km(int dist) {
        return (litersUsed / dist) * 100;
    }

    public double totalCost() {
        return litersUsed * pricePerLiter;
    }
}