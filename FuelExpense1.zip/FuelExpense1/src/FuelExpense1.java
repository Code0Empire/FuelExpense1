public class FuelExpense1 {

    public static void main(String[] args) {

        String carType1 = "Toyota Camry";
        int startKms1 = 50000;
        int endKms1 = 50450;
        double litersUsed1 = 45.0;
        double pricePerLiter1 = 1.50;

        Fuel car1 = new Fuel(carType1, endKms1, startKms1,
                             litersUsed1, pricePerLiter1);

        int distance1 = car1.calcDistance(startKms1, endKms1);
        double kmPL1 = car1.calcKmPL(distance1, litersUsed1);
        double literP100Km1 = car1.calcLiterP100Km(distance1);
        double totalCost1 = car1.totalCost();

        System.out.println("========================================");
        System.out.println("           FUEL EXPENSE REPORT");
        System.out.println("========================================");
        System.out.println("Type of Car    : " + carType1);
        System.out.println("Start km       : " + startKms1);
        System.out.println("End km         : " + endKms1);
        System.out.println("Distance       : " + distance1 + " km");
        System.out.println("Liters Used    : " + litersUsed1 + " L");
        System.out.printf("Km/L           : %.2f%n", kmPL1);
        System.out.printf("Cost           : %.2f%n", totalCost1);
        System.out.printf("L/100km        : %.2f%n", literP100Km1);
        System.out.println("========================================");
    }
}